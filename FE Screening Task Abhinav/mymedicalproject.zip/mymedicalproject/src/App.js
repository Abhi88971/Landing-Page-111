// App.js
import React from 'react';
import HeroImage from './HeroImage';
import ConsultationForm from './ConsultationForm';
import Testimonials from './Testimonials';
import './App.css';

function App() {
  return (
    <div className="App">
      <HeroImage />
      <ConsultationForm />
      <Testimonials />
    </div>
  );
}

export default App;
