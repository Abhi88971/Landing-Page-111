/* HeroImage.js */
import React from 'react';
import './HeroImage.css';
import smallHeroImage from './heropic.jpg';
import doctorImage1 from './doctorimage1.jpeg';
import doctorImage2 from './doctorimage2.jpeg';
const HeroImage = () => {
  return (
    <div>
      <div className="header">
      <div class="heading-container">
  <h1 class="fix-health">Fix Health</h1>
  <p class="caption">Previously Your Physio</p>
</div>


      </div>
      <div className="hero-container">
        <img src={smallHeroImage} className="small-hero-image" alt="small-hero" />
        <h2 className="cap">Our Health has to be our first priority. And I prefer Fix Health <br /> - says actor Mahesh Babu</h2>
      </div>

      <section className="doctor-profiles">
        <h3>Meet Our Doctors</h3>
        <div className="doctor-card">
          <img src={doctorImage2} alt="Doctor 1" />
          <h4>Dr. Jane Doe</h4>
          <p>Physiotherapist</p>
        </div>
        <div className="doctor-card">
          <img src={doctorImage1} alt="Doctor 2" />
          <h4>Dr. John Smith</h4>
          <p>Orthopedic Specialist</p>
        </div>
      </section>
    </div>

    
  );
}

export default HeroImage;
