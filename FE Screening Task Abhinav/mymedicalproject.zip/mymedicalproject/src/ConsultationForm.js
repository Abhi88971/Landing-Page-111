import React, { useState, useEffect } from 'react';
import './ConsultationForm.css';

const ConsultationForm = () => {
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [city, setCity] = useState('');
  const [age, setAge] = useState('');
  const [showExperienceCheckbox, setShowExperienceCheckbox] = useState(true);
  const [showDoctorDropdown, setShowDoctorDropdown] = useState(true);

  useEffect(() => {
    // Fetch doctors data based on the city from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const urlCity = urlParams.get('city');

    // Use the city from URL parameter if available, otherwise use the city entered by the patient
    const fetchCity = urlCity || city;

    if (fetchCity) {
      console.log('Fetching doctors for city:', fetchCity);
      fetch(`http://localhost:3003/doctors?city=${fetchCity}`)
        .then(response => response.json())
        .then(data => setDoctors(data))
        .catch(error => console.error('Error fetching doctors:', error));
    } else {
      console.log('Fetching all doctors');
      // Fetch all doctors
      fetch('http://localhost:3003/doctors')
        .then(response => response.json())
        .then(data => setDoctors(data))
        .catch(error => console.error('Error fetching doctors:', error));
    }
  }, [city]);

  useEffect(() => {
    console.log('Selected Doctor:', selectedDoctor);
  }, [selectedDoctor]);

  const handleCityChange = (event) => {
    const selectedCity = event.target.value;
    setCity(selectedCity);
  };

  const handleAgeChange = (event) => {
    const newAge = event.target.value;
    setAge(newAge);

    // Disable checkbox and dropdown if age is less than 40
    setShowExperienceCheckbox(parseInt(newAge, 10) >= 40);
    setShowDoctorDropdown(parseInt(newAge, 10) >= 40);
  };

  return (
    <div className="form-container">
      <form>
        <div className="form-group">
          <h2>Book a Consultation</h2>
        </div>

        {/* Step 1 */}
        <div className="form-step">
          <div className="form-group">
            <label>Name:</label>
            <input type="text" name="name" required />
          </div>

          <div className="form-group">
            <label>Phone Number:</label>
            <input type="tel" name="phone" required />
          </div>
        </div>

        {/* Step 2 */}
        <div className="form-step">
          <div className="form-group">
            <label>Age:</label>
            <input
              type="number"
              name="age"
              required
              value={age}
              onChange={handleAgeChange}
            />
          </div>

          <div className="form-group">
            <label>City:</label>
            <input type="text" name="city" value={city} onChange={handleCityChange} required />
          </div>

          <div className="form-group">
            <label>Company:</label>
            <input type="text" name="company" required />
          </div>
        </div>

        {/* Step 3 */}
        <div className="form-step label-group">
          <label>Chief Complaints:</label>
          <textarea name="complaints" rows="4" required />
        </div>

        {showExperienceCheckbox && (
          <div className="form-step input-group">
            <label>Previous Experience with Physiotherapy:</label>
            <input type="checkbox" name="previousExperience" />
          </div>
        )}

        {/* Step 5: Select Doctor */}
        <div className="form-step input-group">
          <select name="doctor" onChange={(e) => setSelectedDoctor(JSON.parse(e.target.value))}>
            <option value="">Select a doctor</option>
            {doctors.map((doctor) => (
              <option key={doctor.id} value={JSON.stringify(doctor)}>
                {doctor.name}
              </option>
            ))}
          </select>
        </div>

        {/* Display Selected Doctor's Details */}
        {selectedDoctor && (
          <div className="form-step input-group">
            <p>Name: {selectedDoctor.name}</p>
            <p>Expertise: {selectedDoctor.expertise}</p>
            <p>City: {selectedDoctor.city}</p>
          </div>
        )}

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ConsultationForm;
