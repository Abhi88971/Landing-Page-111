// Testimonials.js
import React from 'react';
import './Testimonials.css';

const Testimonials = () => {
  return (
    <div className="testimonials-container">
      <h2>What Our Patients Say</h2>
      <div className="testimonial">
        <p>"Their sevice is the best. And I prefer Fix Health"</p>
        <p className="testimonial-author">- Vivek Varma from Chittore</p>
      </div>

      <div className="testimonial">
        <p>"Their Consultation is comfortable and friendly. Good choice choosing Fix Health "</p>
        <p className="testimonial-author">- Abhinav Ghomatam from Banglore</p>
      </div>

      {/* Add more testimonials as needed */}
    </div>
  );
};

export default Testimonials;
